"""
Copyright (C) 2023 Adobe.
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# file: common.py
# brief: Global variables and Enumerators
# author Adobe - 3D & Immersive
# copyright 2023 Adobe Inc. All rights reserved.


import sys
import os
import pathlib
import math
import bpy
from bpy.utils import previews

from enum import Enum


# Substance Remote Engine
if sys.platform == "win32":
    SRE_DIR = "AppData/Roaming/Adobe/Substance3DIntegrationTools"
    SRE_BIN = "substance_remote_engine.exe"
elif sys.platform == "linux":
    SRE_DIR = "Adobe/Substance3DIntegrationTools"
    SRE_BIN = "substance_remote_engine"
elif sys.platform == "darwin":
    SRE_DIR = "Library/Application Support/Adobe/Substance3DIntegrationTools"
    SRE_BIN = "substance_remote_engine"

SRE_ENGINE_DICT = {
    "WINDOWS":
        [("DX", "DirectX", "DX"),
         ("OGL", "OpenGL", "OGL"),
         ("CPU", "CPU", "CPU"),
         ("VK", "Vulkan", "VK")],
    "LINUX":
        [("OGL", "OpenGL", "OGL"),
         ("CPU", "CPU", "CPU"),
         ("VK", "Vulkan", "VK")],
    "DARWIN":
        [("MTL", "Metal", "MTL"),
         ("OGL", "OpenGL", "OGL"),
         ("CPU", "CPU", "CPU"),
         ("VK", "Vulkan", "VK")]
}

# Addon
ADDON_PACKAGE = __package__
ADDON_ROOT = os.path.dirname(__file__)

# Draw
DRAW_DEFAULT_FACTOR = 0.3

# Path
PATH_DEFAULT = bpy.path.native_pathsep(os.path.join(pathlib.Path.home(), "Documents/Adobe/Substance3DInBlender/export"))
PATH_LIBARY_DEFAULT = bpy.path.native_pathsep(os.path.join(pathlib.Path.home(), "Desktop"))

# Substance Remote Engine
SRE_HOST = "127.0.0.1"
SRE_PORT = 41646

# Blender Addon Server
SERVER_HOST = "127.0.0.1"
SERVER_ALLOW_LIST = ['127.0.0.1', 'localhost']
SERVER_TIMEOUT_S = 5

# Client
CLIENT_THREAD_THROTTLE_MS = 5
CLIENT_BUFFER_SIZE = 2048


# Render
RENDER_MAX_RESOLUTION_SYNC = [10, 10]
RENDER_KEY = "{}_{}"
RENDER_IMG_UPDATE_DELAY_S = 0.0001


# Toolkit
TOOLKIT_NAME = "Substance3DIntegrationTools"
TOOLKIT_EXT = ".zip"
TOOLKIT_VERSION_FILE = "version.txt"
TOOLKIT_LAG_TIME = 2
TOOLKIT_INSTALL_TIME = 5

# Keep only the latest 3 compatible versions to avoid cluttering
TOOLKIT_EXPECTED_VERSION = ["2.1.1", "2.1.0", "2.0.0"]

# Web site links
WEB_SUBSTANCE_PRERELEASE = "https://www.adobeprerelease.com/beta/3DF9B9CB-7B2C-4B54-E279-86F9A93E82CD"
WEB_SUBSTANCE_TOOLS = "https://substance3d.adobe.com/plugins/substance-in-blender/#:~:text=The%20Substance%203D%20add-on,optimized%20features%20for%20enhanced%20productivity.&text=The%20add-on%20is%20in%20public%20" # noqa
WEB_SUBSTANCE_SHARE = "https://share-beta.substance3d.com/"
WEB_SUBSTANCE_SOURCE = "https://source.substance3d.com/"
WEB_SUBSTANCE_DOCS = "https://substance3d.adobe.com/documentation/integrations/blender-232292555.html"
WEB_SUBSTANCE_FORUMS = "https://community.adobe.com/t5/substance-3d-plugins/ct-p/ct-substance-3d-plugins?page=1&sort=latest_replies&lang=all&tabid=all" # noqa
WEB_SUBSTANCE_DISCORD = "https://discord.gg/substance3d"

# UI Panels
UI_SPACES = (
    ['3D View', 'VIEW_3D'],
    ['Node Editor', 'NODE_EDITOR'],
    ['Image Generic', 'IMAGE_EDITOR']
)

# SHORTCUTS
SHORTCUT_CLASS_NAME = 'SUBSTANCE_MT_MAIN_{}'

# APPLY TYPE
APPLY_TYPE_DICT = [
    ("INSERT", "INSERT", "Insert at the top"),
    ("APPEND", "APPEND", "Append at the bottom"),
]

# IMAGE EXPORT
IMAGE_EXPORT_FORMAT = [
    ("0", "BMP", "*.bmp"),
    ("1", "PNG", "*.png"),
    ("2", "JPEG", "*.jpeg"),
    ("3", "JPEG2000", "*.jp2"),
    ("4", "TARGA", "*.targa"),
    ("5", "TARGA_RAW", "*.targa"),
    ("6", "OPEN_EXR", "*.exr"),
    ("7", "HDR", "*.hdr"),
    ("8", "TIFF", "*.tiff")
]

IMAGE_FORMAT_DICT = [
    ("BMP", "bmp", "*.bmp"),
    ("EXR", "exr", "*.exr"),
    ("GIF", "gif", "*.gif"),
    ("HDR", "hdr", "*.hdr"),
    ("ICO", "ico", "*.ico"),
    ("J2K", "j2k", "*.j2k"),
    ("J2C", "j2c", "*.j2c"),
    ("JP2", "jp2", "*.jp2"),
    ("JPG", "jpg", "*.jpg"),
    ("JIF", "jif", "*.jif"),
    ("JPEG", "jpeg", "*.jpeg"),
    ("JPE", "jpe", "*.jpe"),
    ("JXR", "jxr", "*.jxr"),
    ("WDP", "wdp", "*.wdp"),
    ("HDP", "hdp", "*.hdp"),
    ("PBM", "pbm", "*.pbm"),
    ("PBMRAW", "pbm raw", "*.pbm"),
    ("PFM", "pfm", "*.pfm"),
    ("PGM", "pgm", "*.pgm"),
    ("PGMRAW", "pgm raw", "*.pgm"),
    ("PNG", "png", "*.png"),
    ("PPM", "ppm", "*.ppm"),
    ("TGA", "tga", "*.tga"),
    ("TARGA", "targa", "*.targa"),
    ("TIF", "tif", "*.tif"),
    ("TIFF", "tiff", "*.tiff"),
    ("WAP", "wap", "*.wap"),
    ("WBMP", "wbmp", "*.wbmp"),
    ("WBM", "wbm", "*.wbm"),
    ("WEBP", "webp", "*.webp"),
    ("XPM", "xpm", "*.xpm")
]

IMAGE_BITDEPTH_DICT = {
    "BMP": [("8", "8", "8")],
    "EXR": [("32", "32", "32")],
    "GIF": [("8", "8", "8")],
    "HDR": [("32", "32", "32")],
    "ICO": [("8", "8", "8")],
    "J2K": [("8", "8", "8"), ("16", "16", "16")],
    "J2C": [("8", "8", "8"), ("16", "16", "16")],
    "JP2": [("8", "8", "8"), ("16", "16", "16")],
    "JPG": [("8", "8", "8")],
    "JIF": [("8", "8", "8")],
    "JPEG": [("8", "8", "8")],
    "JPE": [("8", "8", "8")],
    "JXR": [("8", "8", "8"), ("16", "16", "16"), ("32", "32", "32")],
    "WDP": [("8", "8", "8"), ("16", "16", "16"), ("32", "32", "32")],
    "HDP": [("8", "8", "8"), ("16", "16", "16"), ("32", "32", "32")],
    "PBM": [("8", "8", "8")],
    "PBMRAW": [("8", "8", "8")],
    "PFM": [("32", "32", "32")],
    "PGM": [("8", "8", "8"), ("16", "16", "16")],
    "PGMRAW": [("8", "8", "8"), ("16", "16", "16")],
    "PNG": [("8", "8", "8"), ("16", "16", "16")],
    "PPM": [("8", "8", "8"), ("16", "16", "16")],
    "TGA": [("8", "8", "8")],
    "TARGA": [("8", "8", "8")],
    "TIF": [("8", "8", "8"), ("16", "16", "16"), ("32", "32", "32")],
    "TIFF": [("8", "8", "8"), ("16", "16", "16"), ("32", "32", "32")],
    "WAP": [("8", "8", "8")],
    "WBMP": [("8", "8", "8")],
    "WBM": [("8", "8", "8")],
    "WEBP": [("8", "8", "8")],
    "XPM": [("8", "8", "8")]
}

# Icons
ICONS_DICT = previews.new()
ICONS_IMAGES = (
    {"id": "share_icon", "filename": "share.png"},
    {"id": "source_icon", "filename": "source.png"},
    {"id": "random_icon", "filename": "random.png"},
    {"id": "shuffle_icon", "filename": "shuffle.png"},

    {"id": "loading", "filename": "loading.png"},
    {"id": "loading_error", "filename": "loading_error.png"},

    {"id": "render", "filename": "render.png"},
    {"id": "render_queue", "filename": "render_queue.png"},
)

# Outputs Filter
OUTPUTS_FILTER_DICT = (
    ("enabled", "Enabled", "Show enabled outputs", "CHECKMARK", 1),
    ("shader", "Shader", "Show only shader outputs", "MATERIAL", 2),
    ("all", "All", "Show all available outputs", "COLLAPSEMENU", 3)
)

SHADER_OUTPUT_UNKNOWN_USAGE = "UNKNOWN"

# Parameters
INPUTS_MAX_RANDOM_SEED = 32767
INPUT_ANGLE_CONVERSION = math.pi * 2
INPUT_INT_MAX = 2 ** 31
INPUT_UPDATE_DELAY_S = 0.25

# GROUPS
INPUT_DEFAULT_GROUP = "General"
INPUT_CHANNELS_GROUP = "Channels"
INPUT_IMAGE_DEFAULT_GROUP = "Input Images"
INPUT_TECHINCAL_GROUP = "Technical parameters"

# RESOLUTIONS
RESOLUTIONS_DICT = (
    ('5', '32', ''),
    ('6', '64', ''),
    ('7', '128', ''),
    ('8', '256', ''),
    ('9', '512', ''),
    ('10', '1024', ''),
    ('11', '2048', ''),
    ('12', '4096', '')
)


# CLASS_NAME
CLASS_SHADER_INPUTS = "SUBSTANCE_SHP_{}"

CLASS_GRAPH_INPUTS = "SUBSTANCE_SGI_{}"


# PRESET_LABELS
PRESET_DEFAULT = "DEFAULT"
PRESET_CUSTOM = "CUSTOM"


# PRESET_EXTENSION
PRESET_EXTENSION = ".sbsprs"


class Code_RequestEndpoint(Enum):
    system = "Lwnd-CHcT-uJlw-YSw3"
    sbsar = "m7ef-7gYN-zTGu-4D3w"
    preset = "S4Aa-CHHa-IHib-bpY3"


class Code_CallbackEndpoint(Enum):
    render = "UNW4-UkJs-cxug-R2fK"
    link = "cJiQ-IfbV-Tco8-JOaB"


class Code_RequestOp(Enum):
    add = 0
    remove = 1
    update = 2
    kill = 3
    render = 4
    load = 5


class Code_RequestType(Enum):
    r_sync = 1
    r_async = 2


class Code_SbsarOp(Enum):
    load = 0
    reload = 1
    duplicate = 2


class Code_Response(Enum):
    success = 0
    toolkit_already_started = 1
    toolkit_not_running = 2
    toolkit_not_installed = 3
    toolkit_in_use = 4
    toolkit_stop_error = 5
    toolkit_process_error = 6
    toolkit_remove_error = 7
    toolkit_version_error = 8
    toolkit_version_get_error = 9
    toolkit_version_empty_error = 10
    toolkit_version_not_found_error = 11
    toolkit_file_not_recognized_error = 12
    toolkit_file_ext_error = 13
    toolkit_install_error = 14

    client_connection_error = 15
    client_connection_refused_error = 16

    server_request_type_error = 17
    server_already_running = 18
    server_not_running_error = 19
    server_start_error = 20
    server_stop_error = 21

    sbsar_factory_register_error = 22
    sbsar_factory_unregister_error = 23

    sbsar_remove_not_found_error = 24

    shader_preset_load_error = 25

    input_image_empty = 26

    preset_create_no_name_error = 27
    preset_create_get_error = 28
    preset_export_error = 29
    preset_import_error = 30
    preset_import_not_graph = 31


class Code_InputIdentifier(Enum):
    outputsize = "$outputsize"
    randomseed = "$randomseed"
    pixelsize = "$pixelsize"


class Code_OutputSizeSuffix(Enum):
    width = "_width"
    height = "_height"
    linked = "_linked"


class Code_InputType(Enum):
    float = 0
    float2 = 1
    float3 = 2
    float4 = 3
    integer = 4
    integer2 = 8
    integer3 = 9
    integer4 = 10
    image = 5
    string = 6
    font = 7
    other = -1


class Code_InputWidget(Enum):
    combobox = "Combobox"
    slider = "Slider"
    color = "Color"
    togglebutton = "Togglebutton"
    image = "Image"
    angle = "Angle"
    position = "Position"
    nowidget = "NoWidget"


class Code_Input(Enum):
    combobox = "combobox"
    slider_float = "slider_float"
    slider_int = "slider_int"
    other = "other"


class Code_ShaderInputType(Enum):
    image = "image"
    integer = "integer"
    integer_maxmin = "integer_maxmin"
    integer_slider = "integer_slider"
    integer2 = "integer2"
    integer2_maxmin = "integer2_maxmin"
    integer2_slider = "integer2_slider"
    integer3 = "integer3"
    integer3_maxmin = "integer3_maxmin"
    integer3_slider = "integer3_slider"
    integer4 = "integer4"
    integer4_maxmin = "integer4_maxmin"
    integer4_slider = "integer4_slider"
    float = "float"
    float_maxmin = "float_maxmin"
    float_slider = "float_slider"
    float2 = "float2"
    float2_maxmin = "float2_maxmin"
    float2_slider = "float2_slider"
    float3 = "float3"
    float3_maxmin = "float3_maxmin"
    float3_slider = "float3_slider"
    float4 = "float4"
    float4_maxmin = "float4_maxmin"
    float4_slider = "float4_slider"
    enum = "enum"
    other = "other"


class Code_SbsarLoadSuffix(Enum):
    loading = [" (loading...)", "loading"]
    error = [" (error)", "loading_error"]
    render = [" (rendering...)", "render"]
    render_queue = [" (render_queue...)", "render_queue"]
    success = ["", "NONE"]
