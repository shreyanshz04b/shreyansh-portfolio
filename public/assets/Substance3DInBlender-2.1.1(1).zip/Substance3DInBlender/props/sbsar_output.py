"""
Copyright (C) 2023 Adobe.
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# file: props/sbsar_output.py
# brief: Substance Property Groups
# author Adobe - 3D & Immersive
# copyright 2023 Adobe Inc. All rights reserved.


import bpy

from ..thread_ops import SUBSTANCE_Threads
from ..sbsar.async_ops import _render_sbsar
from ..utils import SUBSTANCE_Utils
from ..common import (
    IMAGE_FORMAT_DICT,
    IMAGE_BITDEPTH_DICT
)


class SUBSTANCE_PG_SbsarOutputChannelUse(bpy.types.PropertyGroup):
    value: bpy.props.StringProperty(name="value")


def on_output_update(self, context):
    if not self.shader_callback_enabled:
        return

    _sbsar = context.scene.loaded_sbsars[context.scene.sbsar_index]
    _graph = SUBSTANCE_Utils.get_selected_graph(context)

    SUBSTANCE_Threads.alt_thread_run(_render_sbsar, (context, _sbsar, int(_graph.index)))


def get_colorspace_dict(self, context):
    return SUBSTANCE_Utils.get_colorspaces()


def get_bitdepths(self, context):
    return IMAGE_BITDEPTH_DICT[self.shader_format]


class SUBSTANCE_PG_SbsarOutput(bpy.types.PropertyGroup):
    id: bpy.props.StringProperty(name="id")
    index: bpy.props.IntProperty(name="index")
    name: bpy.props.StringProperty(name="name")
    graphID: bpy.props.StringProperty(name="graphID")
    format: bpy.props.IntProperty(name="format")
    mipmaps: bpy.props.IntProperty(name="mipmaps")
    identifier: bpy.props.StringProperty(name="identifier")
    label: bpy.props.StringProperty(name="label")
    guiDescription: bpy.props.StringProperty(name="guiDescription")
    group: bpy.props.StringProperty(name="group")
    guiVisibleIf: bpy.props.StringProperty(name="guiVisibleIf")
    userTag: bpy.props.StringProperty(name="userTag")
    type: bpy.props.StringProperty(name="type")
    guiType: bpy.props.StringProperty(name="guiType")
    defaultChannelUse: bpy.props.StringProperty(name="defaultChannelUse")
    enabled: bpy.props.BoolProperty(name="enabled")
    channelUseSpecified: bpy.props.BoolProperty(name="channelUseSpecified")
    channelUse: bpy.props.CollectionProperty(type=SUBSTANCE_PG_SbsarOutputChannelUse)

    shader_callback_enabled: bpy.props.BoolProperty(name="shader_callback_enabled", default=False)
    shader_enabled: bpy.props.BoolProperty(
        name="shader_enabled",
        default=False,
        update=on_output_update)
    shader_colorspace: bpy.props.EnumProperty(
        name="shader_colorspace",
        description="The available colorspaces to be applied to this map", # noqa
        items=get_colorspace_dict,
        update=on_output_update)
    shader_format: bpy.props.EnumProperty(
        name="shader_format",
        description="The available colorspaces to be applied to this map", # noqa
        items=IMAGE_FORMAT_DICT,
        update=on_output_update)
    shader_bitdepth: bpy.props.EnumProperty(
        name="shader_bitdepth",
        description="The available colorspaces to be applied to this map", # noqa
        items=get_bitdepths,
        update=on_output_update)

    filepath: bpy.props.StringProperty(name="filepath", default="") # noqa
    filename: bpy.props.StringProperty(name="filename", default="") # noqa

    def init(self, output):
        self.id = str(output.id)
        self.index = output.index
        self.name = output.defaultChannelUse if output.defaultChannelUse != "UNKNOWN" else output.identifier
        self.graphID = str(output.graphID)
        self.format = output.format
        self.mipmaps = output.mipmaps
        self.identifier = output.identifier
        self.label = output.label
        self.guiDescription = output.guiDescription
        self.group = output.group
        self.guiVisibleIf = output.guiVisibleIf
        self.userTag = output.userTag
        self.type = output.type
        self.guiType = output.guiType
        self.defaultChannelUse = output.defaultChannelUse
        self.enabled = output.enabled
        self.channelUseSpecified = output.channelUseSpecified

        for _use in output.channelUse:
            _new_use = self.channelUse.add()
            _new_use.value = _use

    def init_shader(self, shader, default_output):
        if self.name not in shader.outputs:
            self.shader_enabled = default_output["enabled"]
            self.shader_format = default_output["format"]
            self.shader_bitdepth = default_output["bitdepth"]
        else:
            for _output in shader.outputs:
                if _output.id == self.name:
                    self.shader_enabled = _output.enabled
                    self.shader_format = _output.format
                    self.shader_bitdepth = _output.bitdepth
        self.shader_callback_enabled = True

    def init_output(self, default_output):
        self.shader_callback_enabled = False
        self.shader_enabled = default_output.shader_enabled
        self.shader_format = default_output.shader_format
        self.shader_bitdepth = default_output.shader_bitdepth
        self.shader_callback_enabled = True

    def get(self):
        _obj = {
            "id": int(self.id),
            "graphID": int(self.graphID),
            "format": self.format,
            "mipmaps": self.mipmaps,
            "identifier": self.identifier,
            "label": self.label,
            "guiDescription": self.guiDescription,
            "group": self.group,
            "guiVisibleIf": self.guiVisibleIf,
            "userTag": self.userTag,
            "type": self.type,
            "guiType": self.guiType,
            "defaultChannelUse": self.defaultChannelUse,
            "enabled": self.enabled,
            "channelUseSpecified": self.channelUseSpecified,
            "channelUse": [],
            "shader_enabled": self.shader_enabled,
            "shader_colorspace": self.shader_colorspace,
            "shader_format": self.shader_format,
            "shader_bitdepth": self.shader_bitdepth
        }

        for _use in self.channelUse:
            _obj["channelUse"].append(_use.value)
        return _obj
