"""
Copyright (C) 2023 Adobe.
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# file: props/shader.py
# brief: Shader Preset Property Groups
# author Adobe - 3D & Immersive
# copyright 2023 Adobe Inc. All rights reserved.


import bpy
from ..shader.callbacks import SUBSTANCE_ShaderCallbacks
from ..common import IMAGE_FORMAT_DICT, IMAGE_BITDEPTH_DICT
from ..utils import SUBSTANCE_Utils


class SUBSTANCE_PG_ShaderInput(bpy.types.PropertyGroup):
    id: bpy.props.StringProperty(name="id")
    label: bpy.props.StringProperty(name="label")
    type: bpy.props.StringProperty(name="type")

    def init(self, input):
        self.id = input.id
        self.label = input.label
        self.type = input.type


def on_enabled_update(self, context):
    if not self.callback_enabled:
        return
    SUBSTANCE_ShaderCallbacks.on_output_changed(self, context)


def on_shader_colorspace_update(self, context):
    if not self.callback_enabled:
        return
    SUBSTANCE_ShaderCallbacks.on_output_changed(self, context)


def on_shader_format_update(self, context):
    if not self.callback_enabled:
        return

    _callback_enabled = self.callback_enabled
    self.callback_enabled = False
    self.bitdepth = IMAGE_BITDEPTH_DICT[self.format][0][0]
    self.callback_enabled = _callback_enabled
    SUBSTANCE_ShaderCallbacks.on_output_changed(self, context)


def on_shader_bitdepth_update(self, context):
    if not self.callback_enabled:
        return
    SUBSTANCE_ShaderCallbacks.on_output_changed(self, context)


def get_colorspace_dict(self, context):
    return SUBSTANCE_Utils.get_colorspaces()


def get_shader_bitdepths(self, context):
    return IMAGE_BITDEPTH_DICT[self.format]


class SUBSTANCE_PG_ShaderOutput(bpy.types.PropertyGroup):
    id: bpy.props.StringProperty(name="id")
    name: bpy.props.StringProperty(name="name")
    label: bpy.props.StringProperty(name="label")
    optional: bpy.props.BoolProperty(name="optional")
    enabled: bpy.props.BoolProperty(
        name="enabled",
        update=on_enabled_update)
    colorspace: bpy.props.EnumProperty(
        name="colorspace",
        description="The default colorspace to be used when creating the shader network", # noqa 
        items=get_colorspace_dict,
        update=on_shader_colorspace_update)
    format: bpy.props.EnumProperty(
        name="format",
        description="The default format to be used when exporting this maps", # noqa
        items=IMAGE_FORMAT_DICT,
        update=on_shader_format_update)
    bitdepth: bpy.props.EnumProperty(
        name="bitdepth",
        description="The default bitdepth to be applied to this map", # noqa
        items=get_shader_bitdepths,
        update=on_shader_bitdepth_update)
    normal: bpy.props.BoolProperty(name="normal", default=False)
    callback_enabled: bpy.props.BoolProperty(name="callback_enabled", default=False)

    def init(self, output):
        self.id = output.id
        self.name = output.id
        self.label = output.label
        self.enabled = output.enabled
        self.optional = output.optional
        self.format = output.format
        self.bitdepth = output.bitdepth
        self.normal = output.normal
        self.callback_enabled = True
        self.colorspace = output.colorspace

    def to_json(self):
        _object = {
            "id": self.id,
            "label": self.label,
            "enabled": self.enabled,
            "optional": self.optional,
            "colorspace": self.colorspace,
            "format": self.format,
            "bitdepth": self.bitdepth,
        }

        if self.normal:
            _object["normal"] = self.normal
        return _object


class SUBSTANCE_PG_ShaderPreset(bpy.types.PropertyGroup):
    filename: bpy.props.StringProperty(name="filename")
    name: bpy.props.StringProperty(name="name")
    label: bpy.props.StringProperty(name="label")
    modified: bpy.props.BoolProperty(name="modified", default=False)

    inputs: bpy.props.CollectionProperty(type=SUBSTANCE_PG_ShaderInput)
    outputs: bpy.props.CollectionProperty(type=SUBSTANCE_PG_ShaderOutput)

    inputs_class_name: bpy.props.StringProperty(name="inputs_class_name")

    def init(self, shader):
        self.filename = shader.filename
        self.name = shader.name
        self.label = shader.label
        self.inputs_class_name = shader.inputs_class_name

        for _key, _input in shader.inputs.items():
            _parm_item = self.inputs.add()
            _parm_item.init(_input)

        for _key, _output in shader.outputs.items():
            _output_item = self.outputs.add()
            _output_item.init(_output)

    def to_json(self):
        _data = []
        for _output in self.outputs:
            _data.append(_output.to_json())
        return _data
