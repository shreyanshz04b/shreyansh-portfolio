"""
Copyright (C) 2023 Adobe.
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# file: props/sbsar_input.py
# brief: Substance Property Groups
# author Adobe - 3D & Immersive
# copyright 2023 Adobe Inc. All rights reserved.


import bpy


class SUBSTANCE_PG_SbsarInput(bpy.types.PropertyGroup):
    id: bpy.props.StringProperty(name="id")
    name: bpy.props.StringProperty(name="name")
    graphID: bpy.props.StringProperty(name="graphID")
    identifier: bpy.props.StringProperty(name="identifier")
    label: bpy.props.StringProperty(name="label")
    guiDescription: bpy.props.StringProperty(name="label")
    guiGroup: bpy.props.StringProperty(name="guiGroup")
    guiVisibleIf: bpy.props.StringProperty(name="guiVisibleIf")
    userTag: bpy.props.StringProperty(name="userTag")
    type: bpy.props.StringProperty(name="type")
    guiWidget: bpy.props.StringProperty(name="guiWidget")
    showAsPin: bpy.props.BoolProperty(name="showAsPin", default=False)
    useCache: bpy.props.BoolProperty(name="useCache", default=False)
    visibleIf: bpy.props.BoolProperty(name="visibleIf", default=False)
    isHeavyDuty: bpy.props.BoolProperty(name="isHeavyDuty", default=False)

    def init(self, input):
        self.id = str(input.id)
        self.name = input.identifier
        self.graphID = str(input.graphID)
        self.identifier = input.identifier
        self.label = input.label
        self.guiDescription = input.guiDescription
        self.guiGroup = input.guiGroup
        self.guiVisibleIf = input.guiVisibleIf
        self.userTag = input.userTag
        self.type = input.type
        self.guiWidget = input.guiWidget
        self.showAsPin = input.showAsPin
        self.useCache = input.useCache
        self.visibleIf = input.visibleIf
        self.isHeavyDuty = input.isHeavyDuty

    def get(self):
        _obj = {
            "id": int(self.id),
            "graphID": int(self.graphID),
            "identifier": self.identifier,
            "label": self.label,
            "guiDescription": self.guiDescription,
            "guiGroup": self.guiGroup,
            "guiVisibleIf": self.guiVisibleIf,
            "userTag": self.userTag,
            "type": self.type,
            "guiWidget": self.guiWidget,
            "showAsPin": self.showAsPin,
            "useCache": self.useCache,
            "visibleIf": self.visibleIf,
            "isHeavyDuty": self.isHeavyDuty
        }
        return _obj


class SUBSTANCE_PG_SbsarInputGroup(bpy.types.PropertyGroup):
    index: bpy.props.IntProperty(name="index")
    label: bpy.props.StringProperty(name="label")
    collapsed: bpy.props.BoolProperty(default=False)

    def init(self, index, value, addon_prefs):
        self.index = index
        self.label = value
        self.collapsed = addon_prefs.default_group_collapse

    def get(self):
        _obj = {
            "label": self.label,
            "collapsed": self.collapsed
        }
        return _obj
