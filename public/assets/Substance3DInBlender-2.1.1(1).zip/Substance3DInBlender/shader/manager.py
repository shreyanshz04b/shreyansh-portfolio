"""
Copyright (C) 2023 Adobe.
This program is free software: you can redistribute it and/or modify
it under theshad terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# file: shader/manager.py
# brief: Shader presets operation manager
# author Adobe - 3D & Immersive
# copyright 2023 Adobe Inc. All rights reserved.


import os
import traceback

from .shader import ShaderPreset
from ..utils import SUBSTANCE_Utils
from ..factory.shader import SUBSTANCE_ShaderFactory
from ..common import (
    Code_Response,
    ADDON_ROOT
)


class SUBSTANCE_ShaderManager():
    def __init__(self):
        self.shaders = {}

    def initialize(self, addon_prefs):
        _shaders_dir = os.path.join(ADDON_ROOT, "_presets/default").replace('\\', '/')
        for _filepath in os.listdir(_shaders_dir):
            # Load the shader presets
            _result = self.load(_filepath)
            if _result[0] != Code_Response.success:
                SUBSTANCE_Utils.log_data(
                    "ERROR",
                    "Substance file [{}] could not be loaded".format(
                        _filepath),
                    display=True)
                continue
            _shader_preset = ShaderPreset(_filepath, _result[1])
            _new_shader = addon_prefs.shaders.add()
            _new_shader.init(_shader_preset)
            self.register(_shader_preset)
            SUBSTANCE_Utils.log_data("INFO", "Shader Presets [{}] initialized...".format(_filepath))
        return (Code_Response.success, None)

    def load(self, filename):
        try:
            _path = SUBSTANCE_Utils.get_shader_file(filename)
            _data = SUBSTANCE_Utils.get_json(_path)

            return (Code_Response.success, _data)
        except Exception:
            return (Code_Response.shader_preset_load_error, None)

    def register(self, shader):
        self.shaders[shader.filename] = shader
        _result = SUBSTANCE_ShaderFactory.register_class(shader)
        return _result

    def remove_presets(self, shader_presets):
        try:

            return Code_Response.success
        except Exception:
            SUBSTANCE_Utils.log_data("ERROR", "Exception - Shader Preset removal error:")
            SUBSTANCE_Utils.log_traceback(traceback.format_exc())
            return Code_Response.shader_preset_remove_error

    def save_presets(self, shader_preset):
        try:
            _default_shader_file = os.path.join(
                ADDON_ROOT,
                "_presets/default/" + shader_preset["filename"]).replace('\\', '/')
            _custom_shader_file = os.path.join(
                ADDON_ROOT,
                "_presets/custom/" + shader_preset["filename"]).replace('\\', '/')
            _custom_shader_path = os.path.join(
                ADDON_ROOT,
                "_presets/custom").replace('\\', '/')

            # Read Original Shader Preset
            if not os.path.exists(_default_shader_file):
                return Code_Response.shader_preset_default_not_exist_error

            _data = SUBSTANCE_Utils.get_json(_default_shader_file)

            _data["inputs"] = shader_preset["inputs"]
            _data["outputs"] = shader_preset["outputs"]

            # Write Custom Shader Preset
            if not os.path.exists(_custom_shader_path):
                os.mkdir(_custom_shader_path)

            SUBSTANCE_Utils.set_json(_custom_shader_file, _data)

            return Code_Response.success

        except Exception:
            SUBSTANCE_Utils.log_data("ERROR", "Exception - Shader Preset saving error:")
            SUBSTANCE_Utils.log_traceback(traceback.format_exc())
            return Code_Response.shader_preset_save_error
