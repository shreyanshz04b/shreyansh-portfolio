"""
Copyright (C) 2023 Adobe.
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# file: ops/shader.py
# brief: Shader Operators
# author Adobe - 3D & Immersive
# copyright 2023 Adobe Inc. All rights reserved.


import bpy
import os

from ..common import ADDON_ROOT, ADDON_PACKAGE, Code_Response
from ..api import SUBSTANCE_Api
from ..utils import SUBSTANCE_Utils
from ..shader.shader import ShaderPreset


class SUBSTANCE_OT_LoadShaderPresets(bpy.types.Operator):
    bl_idname = 'substance.load_shader_presets'
    bl_label = 'Initialize shader preset'
    bl_description = "Initialize the shader presets"

    def execute(self, context):
        _addon_prefs = context.preferences.addons[ADDON_PACKAGE].preferences
        _addon_prefs.shaders.clear()

        _shaders_dir = os.path.join(ADDON_ROOT, "_presets/default").replace('\\', '/')
        for _filepath in os.listdir(_shaders_dir):
            # Load the shader presets
            _result = SUBSTANCE_Api.shader_load(_filepath)
            if _result[0] != Code_Response.success:
                SUBSTANCE_Utils.log_data(
                    "ERROR",
                    "Substance file [{}] could not be loaded".format(
                        _filepath),
                    display=True)
                continue
            _shader_preset = ShaderPreset(_filepath, _result[1])
            _new_shader = _addon_prefs.shaders.add()
            _new_shader.init(_shader_preset)
            SUBSTANCE_Api.shader_register(_shader_preset)
            SUBSTANCE_Utils.log_data("INFO", "Shader Presets [{}] initialized...".format(_filepath))
        return {'FINISHED'}


class SUBSTANCE_OT_RemoveShaderPresets(bpy.types.Operator):
    bl_idname = 'substance.remove_shader_presets'
    bl_label = 'Remove shader preset'
    bl_description = "Remove the shader presets"

    def execute(self, context):
        _addon_prefs = context.preferences.addons[ADDON_PACKAGE].preferences

        _result = SUBSTANCE_Api.shader_presets_remove(_addon_prefs.shaders)
        if _result != Code_Response.success:
            SUBSTANCE_Utils.log_data("ERROR", "Shader Presets could not be removed...")
            _addon_prefs.shader_presets.clear()
            return {'FINISHED'}

        SUBSTANCE_Utils.log_data("INFO", "Shader Presets fully removed...")
        _addon_prefs.shaders.clear()
        return {'FINISHED'}


class SUBSTANCE_OT_SaveShaderPresets(bpy.types.Operator):
    bl_idname = 'substance.save_shader_presets'
    bl_label = 'Save shader preset'
    bl_description = "Save the shader presets"

    def execute(self, context):
        _addon_prefs = context.preferences.addons[ADDON_PACKAGE].preferences

        for _shader_preset in _addon_prefs.shaders:
            if _shader_preset.modified:
                _inputs = getattr(context.scene, _shader_preset.inputs_class_name)

                _outputs = {}
                for _output in _shader_preset.outputs:
                    _outputs[_output.id] = _output.to_json()

                _obj = {
                    "label": _shader_preset.label,
                    "filename": _shader_preset.filename,
                    "inputs": _inputs.get(),
                    "outputs": _outputs,
                }

                _result = SUBSTANCE_Api.shader_presets_save(_obj)
                if _result != Code_Response.success:
                    SUBSTANCE_Utils.log_data(
                        "ERROR",
                        "Shader Presets [{}] could not be saved...[{}]".format(_obj["label"], _result))
                SUBSTANCE_Utils.log_data("INFO", "Shader Presets [{}] saved...".format(_obj["label"]))

        return {'FINISHED'}


class SUBSTANCE_OT_ResetShaderPreset(bpy.types.Operator):
    bl_idname = 'substance.reset_shader_preset'
    bl_label = 'Reset shader preset'
    bl_description = "Reset the shader preset"

    @classmethod
    def poll(cls, context):
        _addons_prefs, _shader_idx, _shader = SUBSTANCE_Utils.get_selected_shader(context)
        return _shader.modified

    def execute(self, context):
        _addons_prefs, _shader_idx, _shader = SUBSTANCE_Utils.get_selected_shader(context)

        _inputs = getattr(context.scene, _shader.inputs_class_name)
        _inputs.reset()

        # Load the shader presets
        _result = SUBSTANCE_Api.shader_load(_shader.filename)
        if _result[0] != Code_Response.success:
            SUBSTANCE_Utils.log_data(
                "ERROR",
                "Substance file [{}] could not be loaded".format(
                    _shader.filename),
                display=True)
            return {'FINISHED'}

        _outputs = _result[1]["outputs"]
        for _output in _shader.outputs:
            _output.enabled = _outputs[_output.id]["enabled"]
            _output.colorspace = _outputs[_output.id]["colorspace"]
            _output.format = _outputs[_output.id]["format"]
            _output.bitdepth = _outputs[_output.id]["bitdepth"]

        _shader.modified = False

        SUBSTANCE_Utils.log_data(
            "INFO",
            "Shader Presets [{}] is back to default values".format(_shader.label),
            display=True)
        return {'FINISHED'}
