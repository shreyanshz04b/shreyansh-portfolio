"""
Copyright (C) 2023 Adobe.
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# file: ops/material.py
# brief: Material operators
# author Adobe - 3D & Immersive
# copyright 2023 Adobe Inc. All rights reserved.


import bpy

from ..api import SUBSTANCE_Api
from ..utils import SUBSTANCE_Utils
from ..common import Code_Response, Code_RequestType
from ..sbsar.sbsar import SBSAR
from ..thread_ops import SUBSTANCE_Threads
from ..sbsar.async_ops import _render_sbsar


class SUBSTANCE_OT_Version(bpy.types.Operator):
    bl_idname = 'substance.version'
    bl_label = 'Version'
    bl_description = 'Get the current plugin version'

    def execute(self, context):
        _version = SUBSTANCE_Api.version()

        SUBSTANCE_Utils.log_data(
            "INFO",
            "Substance Addon version {}.{}.{}".format(_version[0], _version[1], _version[2]),
            display=True)

        return {'FINISHED'}


class SUBSTANCE_OT_Message(bpy.types.Operator):
    bl_idname = 'substance.send_message'
    bl_label = 'Message'
    bl_description = "Send the user a message"

    type: bpy.props.StringProperty(default="INFO") # noqa
    message: bpy.props.StringProperty(default="") # noqa
    _timer = None

    def modal(self, context, event):
        if event.type == 'TIMER':
            self.cancel(context)
            self.report({self.type}, self.message)
            return {'FINISHED'}
        return {'PASS_THROUGH'}

    def execute(self, context):
        wm = context.window_manager
        self._timer = wm.event_timer_add(time_step=1, window=context.window)
        wm.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def cancel(self, context):
        wm = context.window_manager
        wm.event_timer_remove(self._timer)


def load_sbsar(filename, filepath, uuid=None, type=Code_RequestType.r_async):
    _addon_prefs, _selected_shader_idx, _selected_shader_preset = SUBSTANCE_Utils.get_selected_shader(bpy.context)
    _normal_format = _addon_prefs.default_normal_format
    _output_size = _addon_prefs.default_resolution.get()

    _unique_name = SUBSTANCE_Utils.get_unique_name(filename, bpy.context)

    SUBSTANCE_Utils.log_data("INFO", "Begin loading substance from file [{}]".format(filename), display=True)
    if uuid:
        _data = {
            "uuid": uuid,
            "filepath": filepath,
            "name": _unique_name,
            "$outputsize": _output_size,
            "normal_format": 0 if _normal_format == "DirectX" else 1
        }
    else:
        _data = {
            "filepath": filepath,
            "name": _unique_name,
            "$outputsize": _output_size,
            "normal_format": 0 if _normal_format == "DirectX" else 1
        }

    # Load the sbsar to the SRE
    _result = SUBSTANCE_Api.sbsar_load(_data)
    if _result[0] != Code_Response.success:
        SUBSTANCE_Utils.log_data(
            "ERROR",
            "Substance file [{}] located at [{}] could not be loaded".format(filename, filepath),
            display=True)
        return
    if _result[1]["result"] != Code_Response.success.value:
        SUBSTANCE_Utils.log_data(
            "ERROR",
            "An error ocurred while loading Substance file [{}]. Failed with error [{}]".format(
                filepath, _result[1]["result"]),
            display=True)
        return

    _sbsar = SBSAR(_unique_name, filename, _result[1]["data"], _addon_prefs)
    _loaded_sbsar = bpy.context.scene.loaded_sbsars.add()
    _loaded_sbsar.init(_sbsar)
    _loaded_sbsar.init_shader(_selected_shader_idx, _selected_shader_preset, _addon_prefs.get_default_output())
    SUBSTANCE_Api.sbsar_register(_sbsar)
    bpy.context.scene.sbsar_index = len(bpy.context.scene.loaded_sbsars) - 1

    if type == Code_RequestType.r_async:
        for _idx, _graph in enumerate(_loaded_sbsar.graphs):
            SUBSTANCE_Threads.alt_thread_run(_render_sbsar, (bpy.context, _loaded_sbsar, _idx))

    SUBSTANCE_Utils.log_data("INFO", "Substance from file [{}] loaded".format(filename))


def load_usdz(filename, filepath, uuid=None):
    def load_file():
        bpy.ops.wm.usd_import(filepath=filepath, relative_path=True, set_material_blend=False)
        SUBSTANCE_Utils.log_data(
            "INFO",
            "Substance Connector file [{}] loaded".format(filename),
            display=True)
    SUBSTANCE_Threads.main_thread_run(load_file)
