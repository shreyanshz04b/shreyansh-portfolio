"""
Copyright (C) 2023 Adobe.
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# file: ops/sync.py
# brief: Sinstance Operators
# author Adobe - 3D & Immersive
# copyright 2023 Adobe Inc. All rights reserved.


import os
import bpy

from ..api import SUBSTANCE_Api
from ..utils import SUBSTANCE_Utils
from .common import load_sbsar, Code_RequestType, Code_Response


class SUBSTANCE_OT_SyncInitTools(bpy.types.Operator):
    bl_idname = 'substance.init_tools_sync'
    bl_label = 'Initialize Substance Tools'

    def execute(self, context):
        if not SUBSTANCE_Api.currently_running:
            # Initialize SUBSTANCE_Api
            _result = SUBSTANCE_Api.initialize()
            if _result[0] != Code_Response.success:
                SUBSTANCE_Utils.log_data("ERROR", "[{}] The SRE cannot initialize...".format(_result))
        return {'FINISHED'}


class SUBSTANCE_OT_SyncLoadSBSAR(bpy.types.Operator):
    bl_idname = 'substance.load_sbsar_sync'
    bl_label = 'Load a Substance 3D file'

    filepath: bpy.props.StringProperty(name="filepath", default="") # noqa

    def execute(self, context):
        if len(self.filepath) > 0:
            if self.filepath.endswith('.sbsar'):
                _filename = os.path.basename(self.filepath)
                _filename = _filename.replace(".sbsar", "")

                load_sbsar(_filename, self.filepath, type=Code_RequestType.r_sync)
            else:
                SUBSTANCE_Utils.log_data("ERROR", "[{}] is not a valid sbsar file".format(self.filepath))
        else:
            SUBSTANCE_Utils.log_data("ERROR", "[{}] is empty, is not a valid sbsar file".format(self.filepath))

        return {'FINISHED'}
