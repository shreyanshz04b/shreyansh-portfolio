"""
Copyright (C) 2023 Adobe.
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# file: dispatcher.py
# brief: Async comms handler
# author Adobe - 3D & Immersive
# copyright 2023 Adobe Inc. All rights reserved.


import os
import json

from ..utils import SUBSTANCE_Utils
from ..network.callback import SRE_CallbackInterface

from ..ops.common import load_sbsar, load_usdz
from ..common import Code_CallbackEndpoint as endpoint
from ..thread_ops import SUBSTANCE_Threads


class Server_POST_Link(SRE_CallbackInterface):
    def execute(self, message):
        if message["type"] != endpoint.link.value:
            return
        _pre_data = message["data"]["message"]
        _data = json.loads(_pre_data)

        _file_path = _data["path"]
        _file_name = os.path.basename(_file_path)
        _, _file_ext = os.path.splitext(_file_name)

        if len(_data["path"]) > 0:
            _uuid = _data["uuid"]
            if _file_ext == ".sbsar":
                load_sbsar(_file_name, _file_path, _uuid)
            elif _file_ext == ".usdz":
                load_usdz(_file_name, _file_path, _uuid)
            else:
                def send_message():
                    SUBSTANCE_Utils.log_data(
                        "ERROR",
                        "Substance Connector file [{}] failed to load".format(_file_name),
                        display=True)
                SUBSTANCE_Threads.main_thread_run(send_message)
