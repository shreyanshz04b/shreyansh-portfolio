"""
Copyright (C) 2023 Adobe.
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# file: shader/callbacks.py
# brief: Callbacks for susbtance outputs and properties
# author Adobe - 3D & Immersive
# copyright 2023 Adobe Inc. All rights reserved.


import bpy

from ..thread_ops import SUBSTANCE_Threads
from ..sbsar.async_ops import _render_sbsar, _set_input_visibility
from ..utils import SUBSTANCE_Utils
from ..common import (
    PRESET_CUSTOM,
    Code_InputType,
    Code_InputIdentifier,
    Code_InputWidget,
    Code_OutputSizeSuffix,
    Code_Response
)


class SUBSTANCE_SbsarCallbacks():
    # Output Size
    @staticmethod
    def on_linked_changed(self, context, parm_identifier):
        if not hasattr(self, Code_InputIdentifier.outputsize.value + Code_OutputSizeSuffix.linked.value):
            return

        _linked = getattr(self, Code_InputIdentifier.outputsize.value + Code_OutputSizeSuffix.linked.value)
        _new_width_width = getattr(self, Code_InputIdentifier.outputsize.value + Code_OutputSizeSuffix.width.value)
        if _linked:
            setattr(self, Code_InputIdentifier.outputsize.value + Code_OutputSizeSuffix.height.value, _new_width_width)
        else:
            SUBSTANCE_SbsarCallbacks.on_outputsize_changed(self, context, parm_identifier)

    @staticmethod
    def on_outputsize_changed(self, context, identifier):
        if not self.callback["enabled"]:
            return
        _sbsar = context.scene.loaded_sbsars[context.scene.sbsar_index]
        _graph = SUBSTANCE_Utils.get_selected_graph(context)
        _preset = int(_graph.presets_list)

        if not _graph.outputsize_exists:
            return

        _input = _graph.inputs[Code_InputIdentifier.outputsize.value]
        _output_size_x = getattr(self,  Code_InputIdentifier.outputsize.value + Code_OutputSizeSuffix.width.value)
        _output_size_y = getattr(self,  Code_InputIdentifier.outputsize.value + Code_OutputSizeSuffix.height.value)
        _new_value = [int(_output_size_x), int(_output_size_y)]

        from ..api import SUBSTANCE_Api
        _result = SUBSTANCE_Api.sbsar_input_update(
            context,
            _sbsar,
            _graph,
            _input,
            _new_value,
            SUBSTANCE_SbsarCallbacks.on_input_update
        )

        if _result[0] == Code_Response.success:
            _new_preset_value = SUBSTANCE_Utils.update_preset_outputsize(
                _graph.presets[_preset].value,
                _input,
                Code_InputType.integer2.value,
                _new_value
            )
            _graph.presets[_preset].value = _new_preset_value

    # Parameters
    @staticmethod
    def on_input_update(context, sbsar, graph, input, value):
        _value = SUBSTANCE_Utils.value_fix_type(input.identifier, input.guiWidget, input.type, value)
        if input.guiWidget == Code_InputWidget.image.value:
            if _value == "":
                _value = "NONE"
            else:
                _filepath = bpy.data.images[_value].filepath
                if _filepath == "":
                    _filepath = SUBSTANCE_Utils.render_image_input(bpy.data.images[_value], bpy.context)
                _value = _filepath

        from ..api import SUBSTANCE_Api
        _result = SUBSTANCE_Api.sbsar_input_set(sbsar, graph, input, _value)
        if context is not None and _result[0] == Code_Response.success:
            SUBSTANCE_Threads.alt_thread_run(_set_input_visibility, (
                sbsar,
                graph,
                _result[1]["data"]["inputs"]))
            SUBSTANCE_Threads.alt_thread_run(_render_sbsar, (
                context,
                sbsar,
                int(graph.index)))
            graph.presets[PRESET_CUSTOM].value = _result[1]["data"]["preset"]
        return _result

    @staticmethod
    def on_input_changed(self, context, identifier):
        if not self.callback["enabled"]:
            return

        _sbsar = context.scene.loaded_sbsars[context.scene.sbsar_index]
        _graph = SUBSTANCE_Utils.get_selected_graph(context)
        _preset = int(_graph.presets_list)

        if _graph.presets[_preset].name != PRESET_CUSTOM:
            _graph.preset_callback = False
            _graph.presets_list = _graph.presets[PRESET_CUSTOM].index
            _graph.preset_callback = True

        _input = _graph.inputs[identifier]
        _new_value = getattr(self, identifier)

        from ..api import SUBSTANCE_Api
        SUBSTANCE_Api.sbsar_input_update(
            context,
            _sbsar,
            _graph,
            _input,
            _new_value,
            SUBSTANCE_SbsarCallbacks.on_input_update
        )
